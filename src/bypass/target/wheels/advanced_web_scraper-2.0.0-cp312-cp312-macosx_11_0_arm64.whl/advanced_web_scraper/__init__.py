from .advanced_web_scraper import *

__doc__ = advanced_web_scraper.__doc__
if hasattr(advanced_web_scraper, "__all__"):
    __all__ = advanced_web_scraper.__all__